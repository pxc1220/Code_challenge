import sys

# import os
sys.path.append(sys.path[0] + "/...")


import unittest
from time import sleep
from TestBase.WebDriverSetup import WebDriverSetup
from PageObject.Pages.LT_HomePage import LT_Home
from PageObject.Pages.LT_LoginPage import LT_Login

from selenium.webdriver.common.by import By
from selenium.webdriver.support.ui import WebDriverWait


# Add your username and password
username = "nilepatest001"
password = "Password@1"


class test_LT_LoginPage(WebDriverSetup):
    def test_Login_Page(self):

        driver = self.driver
        self.driver.get("https://clarity.dexcom.com/")
        self.driver.set_page_load_timeout(360)

        # Create an instance of the class so that you we can make use of the methods
        # in the class
        lt_home_page = LT_Home(driver)

        # Click the login button to go to the next page

        lt_home_page.lt_homeuser.click()

        sleep(5)


        # Create an object of the Login Class
        lt_login_obj = LT_Login(driver)

        sleep(5)


        lt_login_obj.lt_login_user_name.send_keys(username)
        lt_login_obj.lt_login_password.send_keys(password)

        sleep(5)

        # Click the login button to go to the dashboard
        lt_login_obj.lt_login_button.click()

        sleep(5)





        print("Login test completed successfully")

        if __name__ == '__main__':
            unittest.main()