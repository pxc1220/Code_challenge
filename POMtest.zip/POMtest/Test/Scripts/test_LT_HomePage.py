import sys

sys.path.append(sys.path[0] + "/...")

from TestBase.WebDriverSetup import WebDriverSetup

from PageObject.Pages.LT_HomePage import LT_Home
import unittest
from selenium import webdriver
from time import sleep


class test_LT_HomePage(WebDriverSetup):

    def test_Home_Page(self):
        driver = self.driver
        self.driver.get("https://clarity.dexcom.com/")
        self.driver.set_page_load_timeout(30)

        web_page_title = "Dexcom Clarity"

        try:
            if driver.title == web_page_title:
                print("WebPage loaded successfully")
                self.assertEqual(driver.title, web_page_title)
        except Exception as error:
            print(error + "WebPage Failed to load")



        sleep(10)


if __name__ == '__main__':
    unittest.main()